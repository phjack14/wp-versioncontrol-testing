# VersionPress frontend

The UI of VersionPress is implemented as a React single-page application. See [Dev-Setup](../docs/Dev-Setup.md) for more.
