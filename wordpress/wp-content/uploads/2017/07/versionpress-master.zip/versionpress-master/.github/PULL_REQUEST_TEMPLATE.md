Resolves #

Write a paragraph or two about the proposed changes here.
